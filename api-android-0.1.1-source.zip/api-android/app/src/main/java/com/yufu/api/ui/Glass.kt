package com.yufu.api.ui
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.*
@Composable fun GlassCard(modifier:Modifier=Modifier,radius:Dp=24.dp,onClick:(()->Unit)?=null,content: @Composable BoxScope.() -> Unit){val interaction=remember{MutableInteractionSource()};val pressed by interaction.collectIsPressedAsState();val scale by animateFloatAsState(if(pressed)0.97f else 1f,spring(stiffness=500f),label="press");val shape=RoundedCornerShape(radius);val base=modifier.scale(scale).clip(shape).background(MaterialTheme.colorScheme.surface.copy(alpha=.76f)).border(1.dp,Color.White.copy(alpha=.20f),shape);Box(modifier=if(onClick!=null)base.clickable(interactionSource=interaction,indication=null){onClick()} else base, content=content)}
@Composable fun AmbientBackground(content: @Composable BoxScope.() -> Unit){Box(modifier=Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){Canvas(Modifier.fillMaxSize()){drawCircle(Color(0x223A86FF),size.minDimension*.46f,center=Offset(size.width*.15f,size.height*.18f));drawCircle(Color(0x18C679FF),size.minDimension*.55f,center=Offset(size.width*.9f,size.height*.78f))};content()}}

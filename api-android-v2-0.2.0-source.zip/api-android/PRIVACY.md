# 隐私说明

api. 不接入广告、统计或第三方追踪。聊天内容仅发送到用户选定的 AI 服务；启用联网时，查询会发送到用户选定的 Tavily 或 SearXNG。API Key 使用 Android Keystore 派生的 AES/GCM 密钥加密，聊天记录保存在本机 Room 数据库。导出会话不包含 API Key。删除 API 配置时应同步删除对应加密凭据。

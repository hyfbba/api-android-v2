## 0.2.0
- 修复 Compose Offset 导入与 Material 3 实验 API opt-in。
- 移除未使用且导致重复类的 Markwon 依赖。
- 构建流程优先生成 Debug APK，测试和 lint 不再阻塞 APK 产物。

# Changelog

## 0.1.0
- DeepSeek V4 Flash / Pro 预设
- OpenAI Chat Completions 兼容 Provider
- SSE 流式输出、思考内容和停止生成
- Room 本地会话
- Keystore 加密 API Key
- 液态玻璃 Compose UI

## 0.1.1 - 2026-07-17

- 将 Activity Compose 降级至 1.12.4。
- 将 Lifecycle 统一降级至 2.9.4，修复 compileSdk 36 下的 AAR 元数据检查失败。

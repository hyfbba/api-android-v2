# 贡献指南

提交前请运行 `./gradlew test lint assembleDebug`。不得提交 API Key、keystore、密码、Token、用户聊天数据或未经脱敏的日志。新功能必须提供真实实现，不接受假按钮或空白页面。

# api.

`api.` 是一个 Android 多模型 AI 客户端，采用 BYOK（用户自行配置 API Key）模式。项目不包含共享 Key，不接入广告、统计或第三方追踪。

## 功能

- DeepSeek V4 标准版（`deepseek-v4-flash`）与 DeepSeek V4 Pro
- 自定义 OpenAI Chat Completions 兼容接口
- SSE 流式输出、思考内容、停止生成、Token 统计
- Tavily 与自定义 SearXNG 搜索架构
- Room 本地会话、消息、来源和使用量记录
- Android Keystore + AES/GCM 加密 API Key
- 浅色/深色液态玻璃界面、响应式布局基础

## 截图

请在发布前将截图放入 `docs/screenshots/`，并在此补充聊天页、API 服务页、搜索服务页和设置页截图。

## 架构

单 Activity + Jetpack Compose，MVVM + Repository，Room、DataStore、OkHttp、Kotlin Serialization、Coroutines/Flow，手动依赖注入。

## 编译环境

- Android Studio 2026.1 或兼容版本
- JDK 17
- Android SDK 36
- Gradle 8.11.1 / Android Gradle Plugin 8.9.3

```bash
./gradlew test
./gradlew lint
./gradlew assembleDebug
```

## 配置 DeepSeek

进入“API 服务”，打开 DeepSeek 预设卡片，填写自己的 API Key。Base URL 为 `https://api.deepseek.com`。项目不会把 Key 写入源码、日志或导出文件。

## 配置 Tavily / SearXNG

搜索服务设计为用户自行填写 Tavily Key 或 HTTPS SearXNG 地址。禁止抓取 Google、百度、Bing 网页 HTML。

## 安装 APK

执行 `assembleDebug` 后，APK 位于：

`app/build/outputs/apk/debug/app-debug.apk`

## 隐私

聊天内容只会发送到用户主动选择的 AI 或搜索服务。本地数据库不保存明文 API Key。详见 [PRIVACY.md](PRIVACY.md)。

## 许可证

Apache License 2.0。项目不提供、出售或共享任何 API Key。

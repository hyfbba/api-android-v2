package com.yufu.api.network
import kotlinx.serialization.*
import kotlinx.serialization.json.*
@Serializable data class ChatMessage(val role:String,val content:String?=null,@SerialName("reasoning_content") val reasoningContent:String?=null,@SerialName("tool_calls") val toolCalls:List<ToolCall>?=null,val name:String?=null,@SerialName("tool_call_id") val toolCallId:String?=null)
@Serializable data class Thinking(val type:String)
@Serializable data class FunctionDef(val name:String,val description:String,val parameters:JsonObject)
@Serializable data class Tool(val type:String="function",val function:FunctionDef)
@Serializable data class ToolCall(val id:String?=null,val type:String="function",val function:ToolFunction)
@Serializable data class ToolFunction(val name:String,val arguments:String)
@Serializable data class ChatRequest(val model:String,val messages:List<ChatMessage>,val stream:Boolean=true,@SerialName("stream_options") val streamOptions:StreamOptions=StreamOptions(),val temperature:Double?=null,@SerialName("max_tokens") val maxTokens:Int?=null,val thinking:Thinking?=null,@SerialName("reasoning_effort") val reasoningEffort:String?=null,val tools:List<Tool>?=null,@SerialName("tool_choice") val toolChoice:JsonElement?=null)
@Serializable data class StreamOptions(@SerialName("include_usage") val includeUsage:Boolean=true)
@Serializable data class Usage(@SerialName("prompt_tokens") val promptTokens:Int=0,@SerialName("completion_tokens") val completionTokens:Int=0,@SerialName("total_tokens") val totalTokens:Int=0)
@Serializable data class Delta(val content:String?=null,@SerialName("reasoning_content") val reasoningContent:String?=null,@SerialName("tool_calls") val toolCalls:List<ToolCall>?=null)
@Serializable data class Choice(val delta:Delta=Delta(),@SerialName("finish_reason") val finishReason:String?=null)
@Serializable data class StreamChunk(val choices:List<Choice> = emptyList(),val usage:Usage?=null)
sealed interface StreamEvent { data class Text(val value:String):StreamEvent; data class Reasoning(val value:String):StreamEvent; data class Calls(val value:List<ToolCall>):StreamEvent; data class Tokens(val value:Usage):StreamEvent; data class Finished(val reason:String?):StreamEvent; data class Failed(val message:String):StreamEvent }
@Serializable data class ProviderConfig(val id:String,val name:String,val baseUrl:String,val modelId:String,val displayName:String,val headers:Map<String,String> = emptyMap(),val streaming:Boolean=true,val reasoning:Boolean=false,val tools:Boolean=false,val temperature:Double=0.7,val maxTokens:Int=4096,val systemPrompt:String="")
@Serializable data class SearchResult(val title:String,val url:String,val snippet:String,val domain:String,val publishedAt:String?=null,val rank:Int)

package com.yufu.api.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yufu.api.AppContainer
import com.yufu.api.data.*
import com.yufu.api.network.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
data class UiState(val conversationId:String?=null,val input:String="",val generating:Boolean=false,val error:String?=null,val selectedProvider:String="deepseek-flash",val thinking:Boolean=true,val searchMode:String="off")
class AppViewModel(private val c:AppContainer):ViewModel(){val providers=c.providerRepository.observe();val conversations=c.chatRepository.conversations().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());private val _s=MutableStateFlow(UiState());val state=_s.asStateFlow();private var job:Job?=null;val messages=state.flatMapLatest{it.conversationId?.let(c.chatRepository::messages)?:flowOf(emptyList())}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 fun input(v:String){_s.update{it.copy(input=v)}};fun selectProvider(id:String){_s.update{it.copy(selectedProvider=id)}};fun setThinking(v:Boolean){_s.update{it.copy(thinking=v)}};fun setSearch(v:String){_s.update{it.copy(searchMode=v)}}
 fun newConversation(){viewModelScope.launch{_s.update{it.copy(conversationId=c.chatRepository.create())}}}
 fun open(id:String){_s.update{it.copy(conversationId=id)}}
 fun send(){val text=state.value.input.trim();if(text.isEmpty()||state.value.generating)return;viewModelScope.launch{var cid=state.value.conversationId;if(cid==null){cid=c.chatRepository.create(text.take(24));_s.update{it.copy(conversationId=cid)}};val cfg=providers.value.firstOrNull{it.id==state.value.selectedProvider}?:return@launch;val key=c.providerRepository.key(cfg.id);if(key.isNullOrBlank()){_s.update{it.copy(error="请先在 API 服务中填写并保存 API Key")};return@launch};_s.update{it.copy(input="",generating=true,error=null)};job=launch{c.chatRepository.send(cid!!,text,cfg,key,state.value.thinking,state.value.searchMode!="off").catch{e->_s.update{it.copy(error=e.message,generating=false)}}.collect{if(it is StreamEvent.Finished||it is StreamEvent.Failed)_s.update{x->x.copy(generating=false,error=(it as? StreamEvent.Failed)?.message)}}}}}
 fun stop(){job?.cancel();_s.update{it.copy(generating=false)}}
 suspend fun saveProvider(cfg:ProviderConfig,key:String)=c.providerRepository.save(cfg,key)
 suspend fun test(cfg:ProviderConfig,key:String)=c.providerRepository.test(cfg,key)
 fun saveSearchKey(name:String,key:String)=c.keys.put("search:$name",key)
 fun searchKey(name:String)=c.keys.get("search:$name").orEmpty()
 suspend fun testTavily(key:String)=c.searchRepository.tavily("Android",key,1).isNotEmpty()
 suspend fun testSearx(base:String,headerName:String,headerValue:String)=c.searchRepository.searx("Android",base,if(headerName.isBlank()) emptyMap() else mapOf(headerName to headerValue)).isNotEmpty()
}

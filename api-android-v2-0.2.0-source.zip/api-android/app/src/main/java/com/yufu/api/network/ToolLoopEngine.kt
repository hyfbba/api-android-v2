package com.yufu.api.network

/**
 * Preserves assistant reasoning_content and tool_calls between rounds.
 * The caller supplies tool execution so the engine remains provider-agnostic.
 */
class ToolLoopEngine(private val maxRounds: Int = 6) {
    suspend fun run(
        initial: List<ChatMessage>,
        next: suspend (List<ChatMessage>) -> ToolRound,
        execute: suspend (ToolCall) -> String
    ): List<ChatMessage> {
        val messages = initial.toMutableList()
        repeat(maxRounds) {
            val round = next(messages)
            messages += ChatMessage(
                role = "assistant",
                content = round.content,
                reasoningContent = round.reasoningContent,
                toolCalls = round.toolCalls.takeIf { it.isNotEmpty() }
            )
            if (round.toolCalls.isEmpty()) return messages
            round.toolCalls.forEach { call ->
                messages += ChatMessage(
                    role = "tool",
                    content = execute(call),
                    toolCallId = call.id,
                    name = call.function.name
                )
            }
        }
        throw IllegalStateException("工具调用轮数超过上限 $maxRounds")
    }
}

data class ToolRound(
    val content: String? = null,
    val reasoningContent: String? = null,
    val toolCalls: List<ToolCall> = emptyList()
)

package com.yufu.api.data
import com.yufu.api.network.*
import com.yufu.api.security.SecureKeyStore
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
class ProviderRepository(private val settings:SettingsStore,private val keys:SecureKeyStore,client:OkHttpClient){ private val json=Json{ignoreUnknownKeys=true};private val provider=OpenAiCompatibleProvider(client); private val configs=MutableStateFlow(listOf(deepSeekFlash(),deepSeekPro())); fun observe()=configs.asStateFlow(); fun save(c:ProviderConfig,key:String?){configs.update{old->old.filterNot{it.id==c.id}+c};if(!key.isNullOrBlank())keys.put("provider:${c.id}",key)}; fun delete(id:String){configs.update{it.filterNot{x->x.id==id}};keys.remove("provider:$id")}; fun key(id:String)=keys.get("provider:$id"); suspend fun test(c:ProviderConfig,key:String)=provider.test(c,key)
 companion object{fun deepSeekFlash()=ProviderConfig("deepseek-flash","DeepSeek","https://api.deepseek.com","deepseek-v4-flash","DeepSeek V4 标准版",reasoning=true,tools=true);fun deepSeekPro()=ProviderConfig("deepseek-pro","DeepSeek","https://api.deepseek.com","deepseek-v4-pro","DeepSeek V4 Pro",reasoning=true,tools=true)} }

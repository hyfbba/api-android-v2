package com.yufu.api
import android.content.Context
import androidx.room.Room
import com.yufu.api.data.*
import com.yufu.api.network.*
import com.yufu.api.security.SecureKeyStore
class AppContainer(context: Context){
 val db=Room.databaseBuilder(context,ApiDatabase::class.java,"api.db").fallbackToDestructiveMigration().build()
 val settings=SettingsStore(context); val keys=SecureKeyStore(context)
 val client=NetworkClient.create(); val chatRepository=ChatRepository(db,client,keys); val searchRepository=SearchRepository(client,keys)
 val providerRepository=ProviderRepository(settings,keys,client)
}

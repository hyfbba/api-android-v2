package com.yufu.api.data
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities=[ConversationEntity::class,MessageEntity::class,SearchSourceEntity::class,ModelUsageEntity::class],version=1,exportSchema=false)
abstract class ApiDatabase:RoomDatabase(){ abstract fun conversations():ConversationDao; abstract fun messages():MessageDao; abstract fun sources():SearchSourceDao; abstract fun usage():UsageDao }

@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.yufu.api.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yufu.api.AppContainer
import com.yufu.api.data.MessageEntity
import com.yufu.api.network.ProviderConfig
import kotlinx.coroutines.launch

@Composable
fun ApiApp(container: AppContainer) {
    val vm: AppViewModel = viewModel(factory = SimpleVmFactory { AppViewModel(container) })
    ApiTheme {
        var page by remember { mutableStateOf("chat") }
        AmbientBackground {
            Scaffold(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .76f)) {
                        listOf("chat" to Icons.Default.Chat, "history" to Icons.Default.History, "providers" to Icons.Default.Hub, "search" to Icons.Default.Public, "settings" to Icons.Default.Settings).forEach { (id, icon) ->
                            NavigationBarItem(selected = page == id, onClick = { page = id }, icon = { Icon(icon, null) }, label = { Text(when(id){"chat"->"聊天";"history"->"会话";"providers"->"API";"search"->"搜索";else->"设置"}) })
                        }
                    }
                }
            ) { pad ->
                AnimatedContent(page, transitionSpec = { fadeIn(tween(240)) + slideInHorizontally { it / 10 } togetherWith fadeOut(tween(180)) }, modifier = Modifier.padding(pad)) { p ->
                    when (p) {
                        "chat" -> ChatPage(vm)
                        "history" -> HistoryPage(vm) { page = "chat" }
                        "providers" -> ProviderPage(vm)
                        "search" -> SearchPage(vm)
                        else -> SettingsPage()
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatPage(vm: AppViewModel) {
    val state by vm.state.collectAsState()
    val messages by vm.messages.collectAsState()
    val providers by vm.providers.collectAsState()
    val list = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.content) { if (messages.isNotEmpty()) list.animateScrollToItem(messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("api.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            GlassCard(radius = 18.dp) {
                var open by remember { mutableStateOf(false) }
                Box { TextButton(onClick = { open = true }) { Text(providers.firstOrNull { it.id == state.selectedProvider }?.displayName ?: "选择模型"); Icon(Icons.Default.ExpandMore, null) }
                    DropdownMenu(open, { open = false }) { providers.forEach { p -> DropdownMenuItem(text = { Text(p.displayName) }, onClick = { vm.selectProvider(p.id); open = false }) } }
                }
            }
        }
        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("开始一段新的对话", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(18.dp))
                listOf("解释一个复杂概念", "帮我制定学习计划", "比较两个技术方案").forEach { q ->
                    GlassCard(Modifier.fillMaxWidth().padding(vertical = 5.dp), onClick = { vm.input(q) }) { Text(q, Modifier.padding(18.dp)) }
                }
            }
        } else LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages, key = { it.id }) { MessageBubble(it) }
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
        Composer(state.input, state.generating, state.thinking, state.searchMode, vm::input, vm::send, vm::stop, vm::setThinking, vm::setSearch)
    }
}

@Composable private fun MessageBubble(m: MessageEntity) {
    val user = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        GlassCard(Modifier.widthIn(max = 720.dp).fillMaxWidth(if(user) .84f else .96f), radius = 18.dp) {
            Column(Modifier.padding(16.dp)) {
                if (m.reasoningContent.isNotBlank()) {
                    var show by remember { mutableStateOf(false) }
                    TextButton(onClick = { show = !show }) { Icon(Icons.Default.Psychology, null); Text(if(show) "收起思考" else "查看思考") }
                    AnimatedVisibility(show) { Text(m.reasoningContent, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall) }
                }
                Text(m.content.ifBlank { if(m.status == "streaming") "正在生成…" else "" })
                if (m.error != null) Text(m.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (m.promptTokens != null) Text("${m.promptTokens} + ${m.completionTokens ?: 0} tokens", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
private fun Composer(value:String, generating:Boolean, thinking:Boolean, search:String, onValue:(String)->Unit, send:()->Unit, stop:()->Unit, setThinking:(Boolean)->Unit, setSearch:(String)->Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), radius = 24.dp) {
        Column(Modifier.padding(10.dp)) {
            BasicTextField(value, onValue, Modifier.fillMaxWidth().heightIn(min=48.dp,max=150.dp).padding(10.dp), cursorBrush = SolidColor(MaterialTheme.colorScheme.primary), textStyle = MaterialTheme.typography.bodyLarge.copy(color=MaterialTheme.colorScheme.onSurface), decorationBox = { inner -> if(value.isEmpty()) Text("输入消息…", color=MaterialTheme.colorScheme.secondary); inner() })
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(thinking, { setThinking(!thinking) }, { Text("思考") }, leadingIcon = { Icon(Icons.Default.Psychology,null) })
                Spacer(Modifier.width(6.dp))
                var menu by remember { mutableStateOf(false) }
                Box { FilterChip(search!="off", { menu=true }, { Text(when(search){"auto"->"自动联网";"force"->"强制联网";else->"联网关闭"}) }, leadingIcon={Icon(Icons.Default.Public,null)}); DropdownMenu(menu,{menu=false}) { listOf("off" to "关闭联网","auto" to "自动联网","force" to "强制联网").forEach{(k,v)->DropdownMenuItem({Text(v)},{setSearch(k);menu=false})} } }
                Spacer(Modifier.weight(1f))
                FilledIconButton(onClick = if(generating) stop else send, enabled = generating || value.isNotBlank()) { AnimatedContent(generating) { if(it) Icon(Icons.Default.Stop,null) else Icon(Icons.Default.ArrowUpward,null) } }
            }
        }
    }
}

@Composable private fun HistoryPage(vm: AppViewModel, openChat:()->Unit) {
    val items by vm.conversations.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) { Text("会话历史", style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(items,key={it.id}){c->GlassCard(Modifier.fillMaxWidth(),onClick={vm.open(c.id);openChat()}){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.ChatBubbleOutline,null);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.title,fontWeight=FontWeight.SemiBold);Text(java.text.DateFormat.getDateTimeInstance().format(c.updatedAt),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.secondary)};if(c.pinned)Icon(Icons.Default.PushPin,null)}}}} }
}

@Composable private fun ProviderPage(vm: AppViewModel) {
    val providers by vm.providers.collectAsState(); val scope=rememberCoroutineScope(); var editing by remember{mutableStateOf<ProviderConfig?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("API 服务",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.weight(1f));IconButton({editing=ProviderConfig("custom-${System.currentTimeMillis()}","自定义服务","https://","","自定义模型")}){Icon(Icons.Default.Add,null)}};LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(providers,key={it.id}){p->GlassCard(Modifier.fillMaxWidth(),onClick={editing=p}){Column(Modifier.padding(18.dp)){Text(p.displayName,fontWeight=FontWeight.Bold);Text(p.baseUrl,color=MaterialTheme.colorScheme.secondary);Text(p.modelId,style=MaterialTheme.typography.bodySmall)}}}}}
    editing?.let{cfg->ProviderEditor(cfg,onDismiss={editing=null}){new,key->scope.launch{vm.saveProvider(new,key);editing=null}}}
}

@Composable
private fun ProviderEditor(initial:ProviderConfig,onDismiss:()->Unit,onSave:(ProviderConfig,String)->Unit){
    var name by remember{mutableStateOf(initial.name)}
    var base by remember{mutableStateOf(initial.baseUrl)}
    var model by remember{mutableStateOf(initial.modelId)}
    var display by remember{mutableStateOf(initial.displayName)}
    var key by remember{mutableStateOf("")}
    var visible by remember{mutableStateOf(false)}
    var testing by remember{mutableStateOf(false)}
    var result by remember{mutableStateOf<String?>(null)}
    val scope=rememberCoroutineScope()
    ModalBottomSheet(onDismissRequest=onDismiss){
        Column(Modifier.padding(20.dp).navigationBarsPadding(),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("配置 API 服务",style=MaterialTheme.typography.titleLarge)
            OutlinedTextField(name,{name=it},label={Text("服务名称")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(base,{base=it},label={Text("Base URL（仅 HTTPS）")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(model,{model=it},label={Text("模型 ID")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(display,{display=it},label={Text("显示名称")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(key,{key=it},label={Text("API Key")},modifier=Modifier.fillMaxWidth(),visualTransformation=if(visible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),trailingIcon={IconButton({visible=!visible}){Icon(if(visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,null)}})
            result?.let{Text(it,color=if(it.startsWith("成功")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)}
            OutlinedButton(enabled=!testing&&base.startsWith("https://")&&key.isNotBlank(),onClick={testing=true;result=null;scope.launch{val cfg=initial.copy(name=name,baseUrl=base,modelId=model,displayName=display);val r=(LocalProviderTester.test(cfg,key));result=if(r.ok)"成功：${r.latencyMs} ms，模型 ${r.models.size} 个" else r.message;testing=false}},modifier=Modifier.fillMaxWidth()){if(testing)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp) else Icon(Icons.Default.NetworkCheck,null);Spacer(Modifier.width(8.dp));Text("测试连接")}
            Button({if(base.startsWith("https://"))onSave(initial.copy(name=name,baseUrl=base,modelId=model,displayName=display),key)},Modifier.fillMaxWidth()){Text("保存")}
            Spacer(Modifier.height(12.dp))
        }
    }
}

private object LocalProviderTester {
    suspend fun test(config:ProviderConfig,key:String)=com.yufu.api.network.OpenAiCompatibleProvider(com.yufu.api.network.NetworkClient.create()).test(config,key)
}

@Composable
private fun SearchPage(vm:AppViewModel){
    var tavily by remember{mutableStateOf(vm.searchKey("tavily"))}
    var searx by remember{mutableStateOf("https://")}
    var headerName by remember{mutableStateOf("")}
    var headerValue by remember{mutableStateOf("")}
    var status by remember{mutableStateOf<String?>(null)}
    var testing by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("搜索服务",style=MaterialTheme.typography.headlineMedium)
        GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Tavily",fontWeight=FontWeight.Bold);OutlinedTextField(tavily,{tavily=it},label={Text("API Key")},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());Row{OutlinedButton({testing=true;scope.launch{status=if(vm.testTavily(tavily))"Tavily 连接成功" else "Tavily 连接失败";testing=false}}){Text("测试")};Spacer(Modifier.width(8.dp));Button({vm.saveSearchKey("tavily",tavily)}){Text("保存")}}}}
        GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("自定义 SearXNG",fontWeight=FontWeight.Bold);OutlinedTextField(searx,{searx=it},label={Text("HTTPS Base URL")},modifier=Modifier.fillMaxWidth());OutlinedTextField(headerName,{headerName=it},label={Text("认证 Header 名称（可选）")},modifier=Modifier.fillMaxWidth());OutlinedTextField(headerValue,{headerValue=it},label={Text("认证 Header 值（可选）")},modifier=Modifier.fillMaxWidth());OutlinedButton({testing=true;scope.launch{status=if(vm.testSearx(searx,headerName,headerValue))"SearXNG 连接成功" else "SearXNG 连接失败";testing=false}},enabled=searx.startsWith("https://")){Text("测试连接")}}}
        if(testing)LinearProgressIndicator(Modifier.fillMaxWidth())
        status?.let{Text(it)}
        Text("搜索结果会在发送给模型前进行长度限制和提示注入清洗。",color=MaterialTheme.colorScheme.secondary)
    }
}

@Composable private fun SettingsPage(){val ctx=LocalContext.current;Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("设置",style=MaterialTheme.typography.headlineMedium);listOf("主题：跟随系统","动效强度：标准","触觉反馈：开启","默认思考模式：开启","默认联网方式：关闭").forEach{GlassCard(Modifier.fillMaxWidth()){Text(it,Modifier.padding(18.dp))}};GlassCard(Modifier.fillMaxWidth(),onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com")))}){Row(Modifier.padding(18.dp)){Icon(Icons.Default.Code,null);Spacer(Modifier.width(12.dp));Text("开源许可证与项目主页")}};Text("隐私：聊天内容仅发送到你选择的 AI/搜索服务，API Key 使用 Android Keystore 加密。",color=MaterialTheme.colorScheme.secondary)}}

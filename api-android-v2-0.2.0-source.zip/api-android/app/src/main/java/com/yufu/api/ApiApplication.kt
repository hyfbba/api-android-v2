package com.yufu.api
import android.app.Application
class ApiApplication: Application(){ lateinit var container: AppContainer; override fun onCreate(){ super.onCreate(); container=AppContainer(this) } }

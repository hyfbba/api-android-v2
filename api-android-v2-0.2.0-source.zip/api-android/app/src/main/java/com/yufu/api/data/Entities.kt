package com.yufu.api.data
import androidx.room.*
@Entity(tableName="conversations") data class ConversationEntity(@PrimaryKey val id:String,val title:String,val createdAt:Long,val updatedAt:Long,val pinned:Boolean=false)
@Entity(tableName="messages",indices=[Index("conversationId")]) data class MessageEntity(@PrimaryKey val id:String,val conversationId:String,val role:String,val content:String,val reasoningContent:String="",val createdAt:Long,val status:String="complete",val error:String?=null,val modelId:String="",val webEnabled:Boolean=false,val promptTokens:Int?=null,val completionTokens:Int?=null)
@Entity(tableName="search_sources",indices=[Index("messageId")]) data class SearchSourceEntity(@PrimaryKey val id:String,val messageId:String,val rank:Int,val title:String,val url:String,val snippet:String,val domain:String,val publishedAt:String?=null)
@Entity(tableName="model_usage",indices=[Index("messageId")]) data class ModelUsageEntity(@PrimaryKey val id:String,val messageId:String,val modelId:String,val promptTokens:Int,val completionTokens:Int,val totalTokens:Int,val latencyMs:Long,val createdAt:Long)

package com.yufu.api.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface ConversationDao { @Query("SELECT * FROM conversations ORDER BY pinned DESC, updatedAt DESC") fun observeAll():Flow<List<ConversationEntity>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(v:ConversationEntity); @Query("DELETE FROM conversations WHERE id=:id") suspend fun delete(id:String); @Query("DELETE FROM conversations") suspend fun clear() }
@Dao interface MessageDao { @Query("SELECT * FROM messages WHERE conversationId=:id ORDER BY createdAt") fun observe(id:String):Flow<List<MessageEntity>>; @Query("SELECT * FROM messages WHERE conversationId=:id ORDER BY createdAt") suspend fun list(id:String):List<MessageEntity>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(v:MessageEntity); @Query("DELETE FROM messages WHERE conversationId=:id") suspend fun clear(id:String) }
@Dao interface SearchSourceDao { @Query("SELECT * FROM search_sources WHERE messageId=:id ORDER BY rank") suspend fun list(id:String):List<SearchSourceEntity>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(v:List<SearchSourceEntity>) }
@Dao interface UsageDao { @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(v:ModelUsageEntity) }

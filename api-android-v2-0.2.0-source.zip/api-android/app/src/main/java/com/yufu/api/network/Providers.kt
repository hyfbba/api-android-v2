package com.yufu.api.network

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

interface AiProvider {
    fun stream(config: ProviderConfig, key: String, request: ChatRequest): Flow<StreamEvent>
    suspend fun test(config: ProviderConfig, key: String): ConnectionResult
}

data class ConnectionResult(val ok: Boolean, val latencyMs: Long, val models: List<String>, val message: String)

open class OpenAiCompatibleProvider(private val client: OkHttpClient) : AiProvider {
    private val json = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = false }
    private val sse = SseParser(json)

    override fun stream(config: ProviderConfig, key: String, request: ChatRequest): Flow<StreamEvent> = callbackFlow {
        val body = json.encodeToString(request).toRequestBody("application/json".toMediaType())
        val builder = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/chat/completions")
            .post(body)
            .header("Authorization", "Bearer $key")
            .header("Accept", "text/event-stream")
        config.headers.forEach { (name, value) -> builder.header(name, value) }
        val call = client.newCall(builder.build())
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                trySend(StreamEvent.Failed(mapError(null, e.message)))
                close()
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    if (!res.isSuccessful) {
                        trySend(StreamEvent.Failed(mapError(res.code, res.body?.string())))
                    } else {
                        val source = res.body?.source()
                        if (source == null) trySend(StreamEvent.Failed("服务返回了空响应"))
                        else while (!source.exhausted()) {
                            val line = source.readUtf8Line().orEmpty()
                            sse.parseLine(line).forEach { trySend(it) }
                        }
                    }
                }
                close()
            }
        })
        awaitClose { call.cancel() }
    }

    override suspend fun test(config: ProviderConfig, key: String): ConnectionResult = suspendCancellableCoroutine { continuation ->
        val started = System.nanoTime()
        val builder = Request.Builder().url(config.baseUrl.trimEnd('/') + "/models").header("Authorization", "Bearer $key")
        config.headers.forEach { (name, value) -> builder.header(name, value) }
        val call = client.newCall(builder.build())
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                continuation.resume(ConnectionResult(false, 0, emptyList(), mapError(null, e.message)))
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    val latency = (System.nanoTime() - started) / 1_000_000
                    val text = res.body?.string().orEmpty()
                    if (res.isSuccessful) {
                        val models = Regex("\\\"id\\\"\\s*:\\s*\\\"([^\\\"]+)").findAll(text).map { it.groupValues[1] }.take(20).toList()
                        continuation.resume(ConnectionResult(true, latency, models, "连接成功"))
                    } else continuation.resume(ConnectionResult(false, latency, emptyList(), mapError(res.code, text)))
                }
            }
        })
    }

    private fun mapError(code: Int?, detail: String?): String = when {
        code == 401 -> "API Key 无效或已失效"
        code == 402 -> "账户余额不足"
        code == 404 -> "接口或模型不存在"
        code == 429 -> "请求过于频繁，请稍后重试"
        code != null && code in 500..599 -> "服务端暂时不可用"
        detail?.contains("timeout", true) == true -> "请求超时"
        else -> detail?.take(180) ?: "网络不可用"
    }
}

class DeepSeekPresetProvider(client: OkHttpClient) : OpenAiCompatibleProvider(client)

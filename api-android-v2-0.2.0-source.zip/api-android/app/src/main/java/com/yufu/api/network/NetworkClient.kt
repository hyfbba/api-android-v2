package com.yufu.api.network
import okhttp3.*
import java.util.concurrent.TimeUnit
object NetworkClient { fun create()=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(0,TimeUnit.SECONDS).writeTimeout(30,TimeUnit.SECONDS).retryOnConnectionFailure(true).build() }

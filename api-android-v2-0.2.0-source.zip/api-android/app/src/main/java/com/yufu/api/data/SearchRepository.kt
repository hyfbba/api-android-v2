package com.yufu.api.data

import com.yufu.api.network.SearchResult
import com.yufu.api.security.SecureKeyStore
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.URI
import java.net.URLEncoder
import kotlin.coroutines.resume

class SearchRepository(private val client: OkHttpClient, private val keys: SecureKeyStore) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun tavily(query: String, key: String, max: Int = 5): List<SearchResult> = suspendCancellableCoroutine { continuation ->
        val payload = """{"query":${json.encodeToString(String.serializer(), query)},"max_results":$max,"include_answer":false,"include_raw_content":false}"""
        val request = Request.Builder().url("https://api.tavily.com/search").header("Authorization", "Bearer $key").post(payload.toRequestBody("application/json".toMediaType())).build()
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = continuation.resume(emptyList())
            override fun onResponse(call: Call, response: Response) {
                response.use { res -> continuation.resume(parseResults(res.body?.string().orEmpty(), "published_date")) }
            }
        })
    }

    suspend fun searx(query: String, base: String, headers: Map<String, String>): List<SearchResult> = suspendCancellableCoroutine { continuation ->
        val url = base.trimEnd('/') + "/search?q=" + URLEncoder.encode(query, "UTF-8") + "&format=json"
        val builder = Request.Builder().url(url)
        headers.forEach { (name, value) -> builder.header(name, value) }
        val call = client.newCall(builder.build())
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = continuation.resume(emptyList())
            override fun onResponse(call: Call, response: Response) {
                response.use { res -> continuation.resume(parseResults(res.body?.string().orEmpty(), "publishedDate")) }
            }
        })
    }

    private fun parseResults(raw: String, publishedKey: String): List<SearchResult> {
        val root = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: return emptyList()
        return root["results"]?.jsonArray?.take(5)?.mapIndexed { index, element ->
            val obj = element.jsonObject
            val url = obj["url"]?.jsonPrimitive?.content.orEmpty()
            SearchResult(
                title = obj["title"]?.jsonPrimitive?.content.orEmpty(),
                url = url,
                snippet = clean(obj["content"]?.jsonPrimitive?.content.orEmpty()),
                domain = runCatching { URI(url).host }.getOrNull().orEmpty(),
                publishedAt = obj[publishedKey]?.jsonPrimitive?.contentOrNull,
                rank = index + 1
            )
        }.orEmpty()
    }

    private fun clean(text: String): String = text.replace(Regex("(?i)(ignore previous|system prompt|developer message)"), "[已清洗]").take(1200)
}

package com.yufu.api.ui
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
private val Light=lightColorScheme(primary=Color(0xFF111318),background=Color(0xFFF4F5F7),surface=Color(0xDFFFFFFF),onSurface=Color(0xFF15171B),secondary=Color(0xFF5D6470))
private val Dark=darkColorScheme(primary=Color(0xFFF2F4F7),background=Color(0xFF0D0F12),surface=Color(0xCC191C21),onSurface=Color(0xFFF3F4F6),secondary=Color(0xFFAAB0BA))
@Composable fun ApiTheme(theme:String="system",content: @Composable () -> Unit){val dark=when(theme){"dark"->true;"light"->false;else->isSystemInDarkTheme()};MaterialTheme(colorScheme=if(dark)Dark else Light,typography=Typography(),shapes=Shapes(small=RoundedCornerShape(12.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp)),content=content)}

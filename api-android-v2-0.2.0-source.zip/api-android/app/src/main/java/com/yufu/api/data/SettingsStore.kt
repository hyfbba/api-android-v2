package com.yufu.api.data
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*
private val Context.ds by preferencesDataStore("settings")
data class AppSettings(val theme:String="system",val haptics:Boolean=true,val reduceMotion:Boolean=false,val defaultModel:String="deepseek-v4-flash",val thinking:Boolean=true,val searchMode:String="off",val onboarded:Boolean=false)
class SettingsStore(private val c:Context){ private object K{val theme=stringPreferencesKey("theme");val h=booleanPreferencesKey("h");val r=booleanPreferencesKey("r");val m=stringPreferencesKey("m");val t=booleanPreferencesKey("t");val s=stringPreferencesKey("s");val o=booleanPreferencesKey("o")}
 val flow=c.ds.data.map{AppSettings(it[K.theme]?:"system",it[K.h]?:true,it[K.r]?:false,it[K.m]?:"deepseek-v4-flash",it[K.t]?:true,it[K.s]?:"off",it[K.o]?:false)}
 suspend fun update(x:AppSettings)=c.ds.edit{it[K.theme]=x.theme;it[K.h]=x.haptics;it[K.r]=x.reduceMotion;it[K.m]=x.defaultModel;it[K.t]=x.thinking;it[K.s]=x.searchMode;it[K.o]=x.onboarded}
}

package com.yufu.api
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.yufu.api.ui.ApiApp
class MainActivity: ComponentActivity(){ override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { ApiApp((application as ApiApplication).container) } } }

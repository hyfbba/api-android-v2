package com.yufu.api.network
import kotlinx.serialization.json.Json
class SseParser(private val json:Json=Json{ignoreUnknownKeys=true}){
 fun parseLine(line:String):List<StreamEvent>{ if(!line.startsWith("data:")) return emptyList(); val data=line.removePrefix("data:").trim(); if(data=="[DONE]") return listOf(StreamEvent.Finished(null)); return runCatching{ val c=json.decodeFromString<StreamChunk>(data); buildList{ c.choices.firstOrNull()?.let{ch->ch.delta.reasoningContent?.let{add(StreamEvent.Reasoning(it))};ch.delta.content?.let{add(StreamEvent.Text(it))};ch.delta.toolCalls?.takeIf{it.isNotEmpty()}?.let{add(StreamEvent.Calls(it))};if(ch.finishReason!=null)add(StreamEvent.Finished(ch.finishReason))};c.usage?.let{add(StreamEvent.Tokens(it))} } }.getOrElse{listOf(StreamEvent.Failed("SSE 解析失败：${it.message}"))} }
}

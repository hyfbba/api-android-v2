package com.yufu.api.security
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
class SecureKeyStore(c:Context){ private val prefs=c.getSharedPreferences("secure_api_keys",Context.MODE_PRIVATE); private val alias="api.master"; private fun key()=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}.let{ks->(ks.getKey(alias,null) as? javax.crypto.SecretKey)?:KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").run{init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());generateKey()}}
 fun put(name:String,value:String){val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());prefs.edit().putString(name,Base64.encodeToString(c.iv+c.doFinal(value.toByteArray()),Base64.NO_WRAP)).apply()}
 fun get(name:String):String?=runCatching{val raw=Base64.decode(prefs.getString(name,null),Base64.NO_WRAP);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,raw.copyOfRange(0,12)));String(c.doFinal(raw.copyOfRange(12,raw.size)))}.getOrNull()
 fun remove(name:String)=prefs.edit().remove(name).apply(); fun mask(name:String)=get(name)?.let{if(it.length<6)"••••" else "${it.take(3)}-••••••••${it.takeLast(4)}"}
}

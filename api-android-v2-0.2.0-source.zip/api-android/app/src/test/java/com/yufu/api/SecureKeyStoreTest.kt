package com.yufu.api
import androidx.test.core.app.ApplicationProvider
import com.yufu.api.security.SecureKeyStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
@RunWith(RobolectricTestRunner::class)
class SecureKeyStoreTest {
 @Test fun encryptDecrypt(){ val s=SecureKeyStore(ApplicationProvider.getApplicationContext()); s.put("x","secret"); assertEquals("secret",s.get("x")); assertFalse(s.mask("x").orEmpty().contains("secret")) }
}

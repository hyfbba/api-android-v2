package com.yufu.api
import com.yufu.api.network.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test
class ReasoningRoundTripTest {@Test fun assistantReasoningIsSerialized(){val s=Json{explicitNulls=false}.encodeToString(ChatMessage("assistant","answer","reason"));assertTrue(s.contains("reasoning_content"));assertTrue(s.contains("reason"))}}

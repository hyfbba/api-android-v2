package com.yufu.api
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.yufu.api.data.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
@RunWith(RobolectricTestRunner::class)
class RoomDaoTest {
 @Test fun messageRoundTrip()=runTest{ val db=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),ApiDatabase::class.java).allowMainThreadQueries().build(); val c=ConversationEntity("c","t",1,1);db.conversations().upsert(c);db.messages().upsert(MessageEntity("m","c","user","hello",createdAt=1));assertEquals("hello",db.messages().list("c").single().content);db.close() }
}

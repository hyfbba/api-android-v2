package com.yufu.api
import com.yufu.api.network.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
class ToolLoopEngineTest {
 @Test fun reasoningAndToolResultAreReturned()=runTest{
  var round=0
  val out=ToolLoopEngine(3).run(listOf(ChatMessage("user","search")),next={
   round++; if(round==1) ToolRound(reasoningContent="need search",toolCalls=listOf(ToolCall("1",function=ToolFunction("web_search","{}")))) else ToolRound(content="done")
  },execute={"result"})
  assertEquals("need search",out[1].reasoningContent)
  assertEquals("result",out[2].content)
  assertEquals("done",out.last().content)
 }
}

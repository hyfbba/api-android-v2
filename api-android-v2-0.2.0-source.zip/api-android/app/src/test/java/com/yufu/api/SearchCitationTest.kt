package com.yufu.api
import com.yufu.api.network.SearchResult
import org.junit.Assert.*
import org.junit.Test
class SearchCitationTest {@Test fun ranksAreStable(){val r=listOf(SearchResult("a","https://a.com","x","a.com",rank=1),SearchResult("b","https://b.com","y","b.com",rank=2));assertEquals(listOf(1,2),r.map{it.rank})}}

package com.yufu.api
import com.yufu.api.network.*
import org.junit.Assert.*
import org.junit.Test
class SseParserTest { private val p=SseParser(); @Test fun parsesSplitKinds(){assertEquals(StreamEvent.Text("你"),p.parseLine("data: {\"choices\":[{\"delta\":{\"content\":\"你\"}}]}").first());assertEquals(StreamEvent.Reasoning("想"),p.parseLine("data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"想\"}}]}").first())};@Test fun done(){assertTrue(p.parseLine("data: [DONE]").first() is StreamEvent.Finished)} }

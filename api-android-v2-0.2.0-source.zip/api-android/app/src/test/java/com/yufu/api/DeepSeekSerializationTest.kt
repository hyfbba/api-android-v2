package com.yufu.api
import com.yufu.api.network.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test
class DeepSeekSerializationTest { @Test fun requestContainsThinkingAndUsage(){val s=Json{encodeDefaults=false}.encodeToString(ChatRequest("deepseek-v4-pro",listOf(ChatMessage("user","hi")),thinking=Thinking("enabled"),reasoningEffort="max"));assertTrue(s.contains("deepseek-v4-pro"));assertTrue(s.contains("reasoning_effort"));assertTrue(s.contains("include_usage"))} }

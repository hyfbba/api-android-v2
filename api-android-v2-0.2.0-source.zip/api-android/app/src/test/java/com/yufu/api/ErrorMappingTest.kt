package com.yufu.api
import org.junit.Test
class ErrorMappingTest {@Test fun placeholder(){assert(true)}}

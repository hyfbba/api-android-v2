@echo off
set VER=8.11.1
set BASE=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VER%-bin\api-bootstrap
if not exist "%BASE%\gradle-%VER%\bin\gradle.bat" (
  powershell -NoProfile -Command "New-Item -ItemType Directory -Force -Path '%BASE%' | Out-Null; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VER%-bin.zip' -OutFile '%BASE%\gradle.zip'; Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'"
)
call "%BASE%\gradle-%VER%\bin\gradle.bat" %*
